from openai import OpenAI
from libs.rekogzator import RekogZator
from libs.poemeiro import Poemeiro
from libs.therepenter import PollyZator
from libs.bootstrapCredentials import AWSClients
from chalice import Chalice, Response
import boto3, uuid, botocore
import os
import json


# Configurar credenciais no ambiente
os.environ["AWS_ACCESS_KEY_ID"] = "AKIA3QWYVJWJT64TMEEZ"
os.environ["AWS_SECRET_ACCESS_KEY"] = "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"
os.environ["AWS_DEFAULT_REGION"] = "us-east-1"

# Inicializa Chalice
app = Chalice(app_name='poemator-lambda')

# Clients
credencial = AWSClients()
rekognition_client =  credencial.get_client('rekognition')
s3_client = credencial.get_client('s3')
polly_client = credencial.get_client('polly')
cliente_openai = credencial.get_client('openai')

# Configurações do bucket S3
BUCKET_NAME = "aula-unifor"

# Classes de funcionalidades
rekogZator = RekogZator(rekognition_client)
poemator = Poemeiro(cliente_openai)
polly_service = PollyZator(polly_client)

#####/// ROTEIRIZACAO DA API *********************************************************************************///

@app.route('/process-image', methods=['POST'], content_types=['multipart/form-data'])
def process_image():
    """
    Endpoint para processar imagem com Rekognition, gerar poema e áudio.
    """
    try:
        request = app.current_request.raw_body
        file_name = f"poemator-{uuid.uuid4().hex}.png"
        temp_file_path = f"/tmp/{file_name}"

        # Salvar imagem temporariamente
        with open(temp_file_path, 'wb') as f:
            f.write(request)

        # Fazer upload para o S3
        s3_client.upload_file(temp_file_path, BUCKET_NAME, file_name)

        # Processar imagem com Rekognition
        labels = rekogZator.rekogDetect(BUCKET_NAME, file_name)
        if not labels:
            return {"error": "Nenhum rótulo detectado."}

        # Gerar poema
        poema = poemator.generate_poema(labels)

        # Gerar áudio
        audio_url = polly_service.sintetizar_texto_para_audio(poema)

        return {"labels": labels, "poema": poema, "audio_url": audio_url}

    except Exception as e:
        return Response(
            body=json.dumps({"error": str(e)}),
            status_code=500,
            headers={'Content-Type': 'application/json'}
        )
